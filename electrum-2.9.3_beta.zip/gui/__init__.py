# To create a new GUI, please add its code to this directory.
# Three objects are passed to the ElectrumGui: config, daemon and plugins
# The Wallet object is instanciated by the GUI

# Notifications about network events are sent to the GUI by using network.register_callback()
